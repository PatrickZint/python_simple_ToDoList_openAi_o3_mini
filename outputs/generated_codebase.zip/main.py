from calculator_controller import CalculatorController


def main():
    controller = CalculatorController()
    controller.view.start()


if __name__ == '__main__':
    main()
